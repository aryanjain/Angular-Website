
import { Component, OnInit,HostListener,ElementRef } from '@angular/core';

@Component({
  selector: 'app-consultation',
  templateUrl: './consultation.component.html',
  styleUrls: ['./consultation.component.css']
})
export class ConsultationComponent implements OnInit {

  fixed;
  @HostListener('window:scroll', ['$event'])
  onWindowScroll($event) {
    const number = $event.target.scrollTop;
    // console.log(number)
    // if (number > 1) {
    //   this.fixed = true;
    //   console.log("in If fixed="+this.fixed);
    // } else if (this.fixed && number < 10) {
    //   this.fixed = false;
    //   console.log("in else fixed="+this.fixed)

    // }
    //console.log("fixed="+this.fixed)
  }


Click=false;
MsgText="";
  constructor() { }

  ngOnInit() {
  }
  
  Show(){
    this.Click=!(this.Click);
    console.log(this.Click);
    
  }
    Answer() 
    {
      if(this.MsgText=='hi' || this.MsgText=='hey'||this.MsgText=='hello')
    {
      this.MsgText="Hey";
    }


    

  }

}






  





