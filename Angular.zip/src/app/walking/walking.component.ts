import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { identifierModuleUrl } from '@angular/compiler';


@Component({
  selector: 'app-walking',
  templateUrl: './walking.component.html',
  styleUrls: ['./walking.component.css']
})
export class WalkingComponent implements OnInit {

  CostValue;
  Th;
    Value;
    registerForm: FormGroup;
      submitted = false;
      datepicker;
      DateError;
      images = [1, 2, 3].map(() => `https://picsum.photos/900/500?random&t=${Math.random()}`);
      constructor(private formBuilder: FormBuilder) { }
  
      ngOnInit() {
          this.registerForm = this.formBuilder.group({
              firstName: ['', Validators.required],
              lastName: ['', Validators.required],
               location: ['', Validators.required],
               time: ['', Validators.required],  
              // email: ['', [Validators.required, Validators.email]],
             date: ['', Validators.required]
              // password: ['', [Validators.required, Validators.minLength(6)]]
          });
      }
  
      // convenience getter for easy access to form fields
      get f() { return this.registerForm.controls; }
  
      onSubmit() {
        console.log("submit");
          this.submitted = true;
  
         // stop here if form is invalid
          if (this.registerForm.invalid) {
              return;
          }
  
          alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value));
         
          this.Value=true;
          this.CostValue=(this.Th)*1000;
        }
       checkDate(value1)
        {
        // var selectedText = (<HTMLInputElement>document.getElementById('datepicker')).value;
        //var selectedText=value1.value;
       // console.log(value1);
        var selectedText=value1.split('-');
        // console.log(selectedText[0]);
        // console.log(selectedText[1]);
        // console.log(selectedText[2]);
          if((selectedText[0]!=2018))
            {
              this.DateError="Error in Date";
              //console.log(selectedText[0]);
            }
              if((selectedText[1]>12))
              {
                this.DateError="Error in Date";
                //console.log(selectedText[1]);
              }
                if((selectedText[2]>32))
                {
                  this.DateError="Error in Date";
                 // console.log(selectedText[2]);
                }
  
                
      //   }
        // Cal(value11)
        // {
        //   this.CostValue=value11*100;
        //         console.log(this.CostValue);
  
        // }
            
  
    }
}




