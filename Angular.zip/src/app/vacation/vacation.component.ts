import { Component, OnInit, ViewChild } from '@angular/core';
import {formatDate } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-vacation',
  templateUrl: './vacation.component.html',
  styleUrls: ['./vacation.component.css']
})
export class VacationComponent implements OnInit {

  onedayprice=200;
  TotalPrice=0;
 vacationForm: FormGroup;
  submitted = false;
  location=["--Select--","Manyata","Kormangla","HSR","BTM Layout"];

  constructor(private formBuilder: FormBuilder) { }

  ngOnInit() {
      this.vacationForm = this.formBuilder.group({
          firstName: ['', Validators.required],
          location: ['', Validators.required],
          fromdate: ['', Validators.required],
          todate: ['', Validators.required]
      });
  }
get f() { return this.vacationForm.controls; }

  onSubmit() 
  {

      this.submitted = true;
        // stop here if form is invalid
      if (this.vacationForm.invalid) {
          return;
      }
        
      var diff = new Date(this.vacationForm.get('todate').value).getTime()-
                 new Date(this.vacationForm.get('fromdate').value).getTime();
     var diffDays =diff / (1000 * 3600 * 24);  
    this.TotalPrice= diffDays*this.onedayprice;
  }
}


  
