import { Component, OnInit,Output,EventEmitter} from '@angular/core';

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {

  enablebutton=false;
  appList2: any[]=[
    {
      "i":"./assets/img6.jfif",
      "p":300,
      "id":"1",
     
    },
    {
      "i":"./assets/img7.jfif",
      "p":500,
      "id":"2",
      
    },
    {
      "i":"./assets/img8.jfif",
      "p":700,
      "id":"3",
  
    },
    {
      "i":"./assets/img11.jfif",
      "p":750,
      "id":"4",
      
    },
    {
      "i":"./assets/img12.jfif",
      "p":800,
      "id":"5",
      
    },
    {
      "i":"./assets/img13.jpg",
      "p":900,
      "id":"6",
      
    },
    {
      "i":"./assets/img14.jfif",
      "p":950,
      "id":"7",
      
    },
    {
      "i":"./assets/img9.jfif",
      "p":650,
      "id":"8",
      
    },
    {
      "i":"./assets/img15.jfif",
      "p":550,
      "id":"9",
      
    },
    {
      "i":"./assets/img16.jfif",
      "p":450,
      "id":"10",
      
    },
    {
      "i":"./assets/img17.jfif",
      "p":350,
      "id":"11",
      
    },
    {
      "i":"./assets/img18.jfif",
      "p":850,
      "id":"12",
      
    },
    ]

    
    
  @Output() child1=new EventEmitter<string>();
  @Output() child2=new EventEmitter<string>();

  count=0;
  sum=0;
   incvalue(price,id)
  {

      this.count+=1;
      this.sum+=price;
  
      this.child1.emit(String(this.count));
      this.child2.emit(String(this.sum));
      console.log(id);
  }

  decvalue(price,id)
  {

    if(this.sum==0)
    {
      return;
    }
    if(this.sum<=0 && this.count<=0){
      this.sum=0;
      this.count=0;
      console.log(id);
    }
      else
    {

      this.count-=1;
      this.sum-=price;
      
      this.child1.emit(String(this.count));
      this.child2.emit(String(this.sum));
      console.log(id);
    }
    
  }

  constructor() { }

  ngOnInit() {
  }


}




