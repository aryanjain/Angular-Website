import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-foodcost',
  templateUrl: './foodcost.component.html',
  styleUrls: ['./foodcost.component.css']
})
export class FoodcostComponent implements OnInit {

  constructor(){

  }
  ngOnInit(){

  }
f1(param1){
  document.getElementById("count").innerHTML=param1;

}

f2(param2){
  document.getElementById("idofp").innerHTML=param2;
}

}






