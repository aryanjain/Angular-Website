import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule} from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { VacationComponent } from './vacation/vacation.component';
import { WalkingComponent } from './walking/walking.component';
import { FeedbackComponent } from './feedback/feedback.component';
import { ConsultationComponent } from './consultation/consultation.component';
import { FoodComponent } from './food/food.component';
import { FoodcostComponent } from './foodcost/foodcost.component';




@NgModule({
  declarations: [
    AppComponent,

    AboutusComponent,

    HomeComponent,

    VacationComponent,

    WalkingComponent,

    FeedbackComponent,

    ConsultationComponent,

    FoodComponent,

    FoodcostComponent,



  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
