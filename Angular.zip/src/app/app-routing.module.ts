import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {AboutusComponent} from './aboutus/aboutus.component';
import {HomeComponent} from './home/home.component';
import {VacationComponent} from './vacation/vacation.component';
import {WalkingComponent} from './walking/walking.component';
import {FeedbackComponent} from './feedback/feedback.component';
import {ConsultationComponent} from './consultation/consultation.component';
import {FoodcostComponent} from './foodcost/foodcost.component';
const routes: Routes = [
 
  // {path:'', redirectTo:' /home' ,pathMatch: 'full'
  // } ,
    
  {
      path:'aboutus',
    component:AboutusComponent,
  },
  {
    path:'home',
    component:HomeComponent,
  },
  {
    path:'petvacation',
    component:VacationComponent,
  },
  {
    path:'walking',
    component:WalkingComponent,
  },
  {
    path:'feedback',
    component:FeedbackComponent,
  },
  {
    path:'consultation',
    component:ConsultationComponent,
  },
  {
    path:'food',
    component:FoodcostComponent,
  },
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
